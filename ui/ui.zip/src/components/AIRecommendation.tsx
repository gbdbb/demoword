import { useMemo, useState } from 'react';
import {
  Card,
  List,
  Tag,
  Button,
  Row,
  Col,
  Table,
  Modal,
  Input,
  Alert,
  Space,
  Descriptions,
  Typography,
  message,
} from 'antd';
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  WarningOutlined,
  LinkOutlined,
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { mockReports, type RecommendationReport, type SentimentType } from '../mockData';

const { TextArea } = Input;

const statusColors = {
  pending: 'orange',
  approved: 'green',
  rejected: 'red',
};

const statusTexts = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

const riskColors = {
  high: 'red',
  medium: 'orange',
  low: 'green',
};

const riskTexts = {
  high: '高风险',
  medium: '中等风险',
  low: '低风险',
};

const sentimentColors: Record<SentimentType, string> = {
  bullish: 'green',
  bearish: 'red',
  neutral: 'default',
};

const sentimentTexts: Record<SentimentType, string> = {
  bullish: '利好',
  bearish: '利空',
  neutral: '中性',
};

const COLORS = ['#1677ff', '#52c41a', '#faad14', '#13c2c2'];

export default function AIRecommendation() {
  const [reports, setReports] = useState<RecommendationReport[]>(mockReports);
  const [selectedReportId, setSelectedReportId] = useState<string>(mockReports[0]?.id || '');
  const [rejectModalVisible, setRejectModalVisible] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const selectedReport = useMemo(
    () => reports.find((report) => report.id === selectedReportId) || null,
    [reports, selectedReportId],
  );
  const pieData = useMemo(
    () =>
      selectedReport
        ? selectedReport.currentHoldings.map((item) => ({
            name: item.coin,
            percentage: item.percentage,
          }))
        : [],
    [selectedReport],
  );

  const adjustmentColumns: ColumnsType<RecommendationReport['proposedChanges'][0]> = [
    {
      title: '币种',
      dataIndex: 'coin',
      key: 'coin',
      width: 100,
    },
    {
      title: '当前数量',
      dataIndex: 'currentAmount',
      key: 'currentAmount',
      width: 120,
      render: (amount: number) => amount.toLocaleString(),
    },
    {
      title: '建议数量',
      dataIndex: 'proposedAmount',
      key: 'proposedAmount',
      width: 120,
      render: (amount: number) => amount.toLocaleString(),
    },
    {
      title: '变化',
      dataIndex: 'change',
      key: 'change',
      width: 100,
      render: (change: number) => (
        <Tag color={change > 0 ? 'green' : change < 0 ? 'red' : 'default'}>
          {change > 0 ? '+' : ''}
          {change}%
        </Tag>
      ),
    },
    {
      title: '调整原因',
      dataIndex: 'reason',
      key: 'reason',
      ellipsis: true,
    },
  ];

  const handleApprove = () => {
    if (!selectedReport) return;
    Modal.confirm({
      title: '确认通过',
      content: '确认要通过此 AI 建议并执行持仓调整吗？',
      okText: '确认通过',
      cancelText: '取消',
      onOk: () => {
        setReports((prev) =>
          prev.map((report) =>
            report.id === selectedReport.id ? { ...report, status: 'approved' } : report,
          ),
        );
        message.success('已通过该建议，等待执行资产调整');
      },
    });
  };

  const handleReject = () => {
    setRejectModalVisible(true);
  };

  const submitReject = () => {
    if (!selectedReport) return;
    if (!rejectReason.trim()) {
      message.warning('请输入驳回原因');
      return;
    }
    setReports((prev) =>
      prev.map((report) =>
        report.id === selectedReport.id ? { ...report, status: 'rejected' } : report,
      ),
    );
    setRejectModalVisible(false);
    setRejectReason('');
    message.info('已驳回该报告并记录原因');
  };

  return (
    <div className="page">
      <div className="page-header">
        <Typography.Title level={3} className="page-title">
          AI 建议报告
        </Typography.Title>
        <Typography.Text type="secondary">
          结合市场消息、持仓分布与风险提示的智能建议
        </Typography.Text>
      </div>

      <Row gutter={[16, 16]}>
        <Col xs={24} lg={8}>
          <Card title="报告列表" bordered={false}>
            <List
              dataSource={reports}
              renderItem={(report) => (
                <List.Item
                  key={report.id}
                  onClick={() => setSelectedReportId(report.id)}
                  className={selectedReportId === report.id ? 'report-item active' : 'report-item'}
                >
                  <List.Item.Meta
                    title={
                      <Space>
                        <span>报告 {report.id}</span>
                        <Tag color={statusColors[report.status]}>{statusTexts[report.status]}</Tag>
                      </Space>
                    }
                    description={report.date}
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>

        <Col xs={24} lg={16}>
          {selectedReport && (
            <Space direction="vertical" size={16} style={{ width: '100%' }}>
              <Card title="建议摘要" bordered={false}>
                <Descriptions column={2} size="middle">
                  <Descriptions.Item label="报告编号">{selectedReport.id}</Descriptions.Item>
                  <Descriptions.Item label="生成时间">{selectedReport.date}</Descriptions.Item>
                  <Descriptions.Item label="状态">
                    <Tag color={statusColors[selectedReport.status]}>
                      {statusTexts[selectedReport.status]}
                    </Tag>
                  </Descriptions.Item>
                  <Descriptions.Item label="风险等级">
                    <Tag icon={<WarningOutlined />} color={riskColors[selectedReport.riskLevel]}>
                      {riskTexts[selectedReport.riskLevel]}
                    </Tag>
                  </Descriptions.Item>
                  <Descriptions.Item label="AI 总体判断" span={2}>
                    <Alert message={selectedReport.aiJudgment} type="info" showIcon />
                  </Descriptions.Item>
                </Descriptions>
              </Card>

              <Card title="关联市场消息" bordered={false}>
                <List
                  dataSource={selectedReport.relatedNews}
                  renderItem={(news) => (
                    <List.Item
                      key={news.id}
                      actions={[
                        <Button
                          type="link"
                          icon={<LinkOutlined />}
                          href={news.source}
                          target="_blank"
                          key="link"
                        >
                          来源
                        </Button>,
                      ]}
                    >
                      <List.Item.Meta
                        title={
                          <Space>
                            <Tag color="blue">{news.coin}</Tag>
                            <Tag color={sentimentColors[news.sentiment]}>
                              {sentimentTexts[news.sentiment]}
                            </Tag>
                            <span className="subtle-text">{news.time}</span>
                          </Space>
                        }
                        description={news.summary}
                      />
                    </List.Item>
                  )}
                />
              </Card>

              <Card title="当前持仓快照" bordered={false}>
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      nameKey="name"
                      labelLine={false}
                      label={({ name, value }) => `${name} ${value}%`}
                      outerRadius={90}
                      fill="#8884d8"
                      dataKey="percentage"
                    >
                      {pieData.map((item, index) => (
                        <Cell key={item.name} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Card>

              {selectedReport.proposedChanges.length > 0 && (
                <Card title="调整建议方案" bordered={false}>
                  <Table
                    columns={adjustmentColumns}
                    dataSource={selectedReport.proposedChanges}
                    rowKey="coin"
                    pagination={false}
                  />
                </Card>
              )}

              {selectedReport.status === 'pending' && (
                <Card bordered={false}>
                  <Space size="large">
                    <Button
                      type="primary"
                      size="large"
                      icon={<CheckCircleOutlined />}
                      onClick={handleApprove}
                    >
                      通过
                    </Button>
                    <Button
                      danger
                      size="large"
                      icon={<CloseCircleOutlined />}
                      onClick={handleReject}
                    >
                      驳回
                    </Button>
                  </Space>
                </Card>
              )}
            </Space>
          )}
        </Col>
      </Row>

      <Modal
        title="驳回原因"
        open={rejectModalVisible}
        onOk={submitReject}
        onCancel={() => {
          setRejectModalVisible(false);
          setRejectReason('');
        }}
        okText="确认驳回"
        cancelText="取消"
      >
        <TextArea
          rows={4}
          placeholder="请填写驳回原因，方便模型迭代与记录"
          value={rejectReason}
          onChange={(e) => setRejectReason(e.target.value)}
        />
      </Modal>
    </div>
  );
}
