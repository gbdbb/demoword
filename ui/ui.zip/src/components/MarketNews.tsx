import { useMemo, useState } from 'react';
import { Table, Tag, Select, Space, Card, Button, Typography } from 'antd';
import { LinkOutlined, FilterOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { mockNews, type NewsItem, type SentimentType } from '../mockData';

const { Option } = Select;

const sentimentColors: Record<SentimentType, string> = {
  bullish: 'green',
  bearish: 'red',
  neutral: 'default',
};

const sentimentTexts: Record<SentimentType, string> = {
  bullish: '利好',
  bearish: '利空',
  neutral: '中性',
};

export default function MarketNews() {
  const [selectedCoin, setSelectedCoin] = useState<string>('all');
  const [selectedSentiment, setSelectedSentiment] = useState<string>('all');

  const filteredData = useMemo(
    () =>
      mockNews.filter((item) => {
        const coinMatch = selectedCoin === 'all' || item.coin === selectedCoin;
        const sentimentMatch =
          selectedSentiment === 'all' || item.sentiment === selectedSentiment;
        return coinMatch && sentimentMatch;
      }),
    [selectedCoin, selectedSentiment],
  );

  const columns: ColumnsType<NewsItem> = [
    {
      title: '发布时间',
      dataIndex: 'time',
      key: 'time',
      width: 180,
      sorter: (a, b) => new Date(a.time).getTime() - new Date(b.time).getTime(),
      defaultSortOrder: 'descend',
    },
    {
      title: '币种',
      dataIndex: 'coin',
      key: 'coin',
      width: 100,
      render: (coin: string) => <Tag color="blue">{coin}</Tag>,
    },
    {
      title: '情绪',
      dataIndex: 'sentiment',
      key: 'sentiment',
      width: 100,
      render: (sentiment: SentimentType) => (
        <Tag color={sentimentColors[sentiment]}>{sentimentTexts[sentiment]}</Tag>
      ),
    },
    {
      title: '消息摘要',
      dataIndex: 'summary',
      key: 'summary',
      ellipsis: true,
    },
    {
      title: '操作',
      key: 'action',
      width: 140,
      render: (_, record) => (
        <Button type="link" icon={<LinkOutlined />} href={record.source} target="_blank">
          查看详情
        </Button>
      ),
    },
  ];

  return (
    <div className="page">
      <div className="page-header">
        <Typography.Title level={3} className="page-title">
          消息列表
        </Typography.Title>
        <Typography.Text type="secondary">实时追踪 AI 采集的链上和市场资讯</Typography.Text>
      </div>

      <Card>
        <Space style={{ marginBottom: 16 }} size="middle" wrap>
          <Space>
            <FilterOutlined />
            <Typography.Text strong>筛选条件</Typography.Text>
          </Space>
          <Space size="middle" wrap>
            <span>币种</span>
            <Select value={selectedCoin} onChange={setSelectedCoin} style={{ width: 140 }}>
              <Option value="all">全部</Option>
              <Option value="BTC">BTC</Option>
              <Option value="ETH">ETH</Option>
              <Option value="SOL">SOL</Option>
            </Select>
            <span>情绪</span>
            <Select
              value={selectedSentiment}
              onChange={setSelectedSentiment}
              style={{ width: 140 }}
            >
              <Option value="all">全部</Option>
              <Option value="bullish">利好</Option>
              <Option value="bearish">利空</Option>
              <Option value="neutral">中性</Option>
            </Select>
          </Space>
        </Space>

        <Table
          columns={columns}
          dataSource={filteredData}
          rowKey="id"
          pagination={{
            pageSize: 8,
            showSizeChanger: false,
            showTotal: (total) => `共 ${total} 条消息`,
          }}
        />
      </Card>
    </div>
  );
}
