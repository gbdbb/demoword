// 模拟数据文件

export type SentimentType = 'bullish' | 'bearish' | 'neutral';

export interface NewsItem {
  id: string;
  time: string;
  coin: string;
  sentiment: SentimentType;
  summary: string;
  source: string;
}

export interface HoldingItem {
  coin: string;
  amount: number;
  percentage: number;
  value: number;
}

export interface RecommendationReport {
  id: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  aiJudgment: string;
  riskLevel: 'high' | 'medium' | 'low';
  relatedNews: NewsItem[];
  currentHoldings: HoldingItem[];
  proposedChanges: {
    coin: string;
    currentAmount: number;
    proposedAmount: number;
    change: number;
    reason: string;
  }[];
}

export const mockNews: NewsItem[] = [
  {
    id: '1',
    time: '2024-12-14 10:30',
    coin: 'BTC',
    sentiment: 'bullish',
    summary: 'MicroStrategy 再次购入 1.5 亿美元比特币，机构持续增持信号明确',
    source: 'https://example.com/news/1',
  },
  {
    id: '2',
    time: '2024-12-14 09:15',
    coin: 'ETH',
    sentiment: 'bullish',
    summary: '以太坊与 Layer2 交易量创新高，链上活跃度持续提升',
    source: 'https://example.com/news/2',
  },
  {
    id: '3',
    time: '2024-12-14 08:45',
    coin: 'BTC',
    sentiment: 'bearish',
    summary: '美联储官员释放鹰派信号，短期内加密市场可能承压',
    source: 'https://example.com/news/3',
  },
  {
    id: '4',
    time: '2024-12-13 16:20',
    coin: 'SOL',
    sentiment: 'bullish',
    summary: 'Solana 生态 TVL 突破 50 亿美元，DeFi 增长势头强劲',
    source: 'https://example.com/news/4',
  },
  {
    id: '5',
    time: '2024-12-13 14:30',
    coin: 'ETH',
    sentiment: 'neutral',
    summary: '以太坊 Gas 费用回落至近月低点，网络使用成本优化',
    source: 'https://example.com/news/5',
  },
  {
    id: '6',
    time: '2024-12-13 11:00',
    coin: 'BTC',
    sentiment: 'neutral',
    summary: '比特币现货 ETF 连续三日资金流入放缓，市场观望情绪升温',
    source: 'https://example.com/news/6',
  },
  {
    id: '7',
    time: '2024-12-12 18:00',
    coin: 'SOL',
    sentiment: 'bearish',
    summary: 'Solana 网络出现短暂延迟，技术稳定性再获关注',
    source: 'https://example.com/news/7',
  },
  {
    id: '8',
    time: '2024-12-12 15:30',
    coin: 'BTC',
    sentiment: 'bullish',
    summary: '灰度比特币信托折价率收窄至 5% 以下，市场情绪回暖',
    source: 'https://example.com/news/8',
  },
];

export const mockHoldings: HoldingItem[] = [
  { coin: 'BTC', amount: 2.5, percentage: 45, value: 110250 },
  { coin: 'ETH', amount: 15, percentage: 28, value: 68600 },
  { coin: 'SOL', amount: 500, percentage: 18, value: 44100 },
  { coin: 'USDT', amount: 22000, percentage: 9, value: 22000 },
];

export const mockHoldingHistory = [
  { date: '12-08', BTC: 42, ETH: 26, SOL: 20, USDT: 12 },
  { date: '12-09', BTC: 43, ETH: 27, SOL: 19, USDT: 11 },
  { date: '12-10', BTC: 44, ETH: 28, SOL: 18, USDT: 10 },
  { date: '12-11', BTC: 45, ETH: 27, SOL: 18, USDT: 10 },
  { date: '12-12', BTC: 46, ETH: 27, SOL: 17, USDT: 10 },
  { date: '12-13', BTC: 45, ETH: 28, SOL: 18, USDT: 9 },
  { date: '12-14', BTC: 45, ETH: 28, SOL: 18, USDT: 9 },
];

export const mockReports: RecommendationReport[] = [
  {
    id: 'R001',
    date: '2024-12-14 11:00',
    status: 'pending',
    aiJudgment: '建议降低 BTC 持仓比例，增加 ETH 配置',
    riskLevel: 'medium',
    relatedNews: mockNews.slice(0, 3),
    currentHoldings: mockHoldings,
    proposedChanges: [
      {
        coin: 'BTC',
        currentAmount: 2.5,
        proposedAmount: 2.2,
        change: -12,
        reason: '短期鹰派信号可能对 BTC 造成压力，建议适度降低仓位',
      },
      {
        coin: 'ETH',
        currentAmount: 15,
        proposedAmount: 18,
        change: 20,
        reason: 'Layer2 活跃度提升，ETH 基本面向好，建议增持',
      },
      {
        coin: 'SOL',
        currentAmount: 500,
        proposedAmount: 500,
        change: 0,
        reason: '保持现有仓位，观察生态发展',
      },
      {
        coin: 'USDT',
        currentAmount: 22000,
        proposedAmount: 15000,
        change: -31.8,
        reason: '降低现金持有比例，优化资金利用效率',
      },
    ],
  },
  {
    id: 'R002',
    date: '2024-12-13 14:00',
    status: 'approved',
    aiJudgment: '市场情绪稳定，维持现有配置',
    riskLevel: 'low',
    relatedNews: mockNews.slice(3, 6),
    currentHoldings: mockHoldings,
    proposedChanges: [],
  },
  {
    id: 'R003',
    date: '2024-12-12 16:30',
    status: 'rejected',
    aiJudgment: '建议大幅增持 SOL',
    riskLevel: 'high',
    relatedNews: mockNews.slice(6, 8),
    currentHoldings: mockHoldings,
    proposedChanges: [
      {
        coin: 'SOL',
        currentAmount: 500,
        proposedAmount: 800,
        change: 60,
        reason: '生态 TVL 快速增长，但仍需关注技术稳定性',
      },
    ],
  },
];

export const getTotalAssetValue = (): number =>
  mockHoldings.reduce((total, item) => total + item.value, 0);

export const getUnreadNewsCount = (): number => 3;

export const getPendingReportsCount = (): number =>
  mockReports.filter((report) => report.status === 'pending').length;
